import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Reader {
        public static List<Point> readPoints(String inFile) throws FileNotFoundException {
                File in = new File(inFile);
                List<Point> Points = new ArrayList<>();
                try (Scanner sc = new Scanner(in)) {
                        while (sc.hasNext()) {

                                String line = sc.nextLine();
                                String[] reads = line.split(",");
                                double x = Double.parseDouble(reads[0].trim());
                                double y = Double.parseDouble(reads[1].trim());
                                double z = Double.parseDouble(reads[2].trim());
                                Points.add(new Point(x, y, z));
                                sc.nextLine();
                        }
                } catch (FileNotFoundException e) {
                        System.out.println("Not openable");
                }
                return Points;

        }
        public static void writePoints(List<Point> points){
                try {
                     PrintStream ps = new PrintStream("drawMe.txt");
                     points.forEach(point -> ps.println(point));

                } catch (FileNotFoundException e) {
                        throw new RuntimeException(e);
                }

        }
}
