import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String [] args) throws IllegalAccessException, FileNotFoundException {
        if (args.length != 1) {
            throw new IllegalAccessException(
                    "Expected 1 file name.");
        }
        String path = args[0];
        List<Point> points = new ArrayList<>();
        points = Reader.readPoints(path);
        points.stream().forEach(System.out::println);
        Reader.writePoints(points);
    }
}
